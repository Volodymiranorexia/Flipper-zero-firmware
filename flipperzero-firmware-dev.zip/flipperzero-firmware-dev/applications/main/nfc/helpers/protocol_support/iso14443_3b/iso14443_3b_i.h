#pragma once

#include <nfc/protocols/iso14443_3b/iso14443_3b.h>

#include "iso14443_3b.h"

bool nfc_scene_saved_menu_on_event_iso14443_3b_common(NfcApp* instance, uint32_t event);
